const config = {
  apiUrl: 'http://localhost:3449'
};

export default config;